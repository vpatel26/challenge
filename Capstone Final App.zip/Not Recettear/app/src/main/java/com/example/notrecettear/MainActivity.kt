package com.example.notrecettear

import android.annotation.SuppressLint
import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Math.random

class MainActivity : AppCompatActivity() {
    //basic economics
    var money = 1000
    val moneyLabel: TextView = findViewById(R.id.Money_TextView)

    //basic UI
    val NumberOfDaysTextView: TextView = findViewById(R.id.Day_TextView)
    val NextDayButton: Button = findViewById(R.id.Next_Day_Button)
    var NumberOfday = 1

    //bread
    var breadPrice = 50
    var breadPriceChangeValue = 0
    val breadStock = 0
    val SellBreadButton: Button = findViewById(R.id.sell_Bread_Button)
    val BuyBreadButton: Button = findViewById(R.id.buy_Bread_Button)

    //Cookie
    var cookiePrice = 100
    var cookiePriceChangeValue = 0
    val cookieStock = 0
    val SellcookieButton: Button = findViewById(R.id.sell_Cookie_Button)
    val BuycookieButton: Button = findViewById(R.id.buy_Cookie_Button)

    //Toast
    var toastPrice = 100000
    var toastPriceChangeValue = 0
    val toastStock = 0
    val SelltoastButton: Button = findViewById(R.id.sell_Toast_Button)
    val BuytoastButton: Button = findViewById(R.id.buy_Toast_Button)

    //Iron Sword
    var sword1Price = 1000
    var sword1PriceChangeValue = 0
    val sword1Stock = 0
    val Sellsword1Button: Button = findViewById(R.id.sell_Sword1_Button)
    val Buysword1Button: Button = findViewById(R.id.buy_Sword1_Button)

    //Steel Sword
    var sword2Price = 2000
    var sword2PriceChangeValue = 0
    val sword2Stock = 0
    val Sellsword2Button: Button = findViewById(R.id.sell_Sword2_Button)
    val Buysword2Button: Button = findViewById(R.id.buy_Sword2_Button)

    //Spear
    var spearPrice = 500
    var spearPriceChangeValue = 0
    val spearStock = 0
    val SellspearButton: Button = findViewById(R.id.sell_Sword2_Button)
    val BuyspearButton: Button = findViewById(R.id.buy_Sword2_Button)
    //Halberd
    var halberdPrice = 2500
    var halberdPriceChangeValue = 0
    val halberdStock = 0
    val SellhalberdButton: Button = findViewById(R.id.sell_Spear_Button)
    val BuyhalberdButton: Button = findViewById(R.id.buy_Spear_Button)
    //Bow
    var bowPrice = 750
    var bowPriceChangeValue = 0
    val bowStock = 0
    val SellbowButton: Button = findViewById(R.id.sell_Bow_Button)
    val BuybowButton: Button = findViewById(R.id.buy_Bow_Button)
    //Spear
    var leatherarmorPrice = 700
    var leatherarmorPriceChangeValue = 0
    val leatherarmorStock = 0
    val SellleatherarmorButton: Button = findViewById(R.id.sell_LeatherArmor_Button)
    val BuyleatherarmorButton: Button = findViewById(R.id.buy_LeatherArmor_Button)
    //Spear
    var chainmailarmorPrice = 1600
    var chainmailarmorPriceChangeValue = 0
    val chainmailarmorStock = 0
    val SellchainmailarmorButton: Button = findViewById(R.id.sell_ChainmailArmor_Button)
    val BuychainmailarmorButton: Button = findViewById(R.id.buy_ChainmailArmor_Button)
    //info
    //val infoButton: Button = findViewById(R.id.Info_button)
    //val infodialog = AlertDialog.Builder(this)
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val infoButton: Button = findViewById(R.id.Info_button)
        val infodialog = AlertDialog.Builder(this)

        NextDayButton.setOnClickListener() {
            NextDay()
        }
        SellBreadButton.setOnClickListener() {
            if (breadStock > 0) {
                breadStock - 1
                money + breadPrice
                Money_TextView.text = "gold $money"
                BreadStockTextView.text = "stock $breadStock"
            }
        }
        BuyBreadButton.setOnClickListener() {
            if (money >= breadPrice) {
                money - breadPrice
                breadStock + 1
                Money_TextView.text = "gold $money"
                BreadStockTextView.text = "stock $breadStock"
            }
        }
        SellcookieButton.setOnClickListener() {
            if (cookieStock > 0) {
                cookieStock - 1
                money + cookiePrice
                Money_TextView.text = "gold $money"
                BreadStockTextView.text = "stock $cookieStock"
            }
        }
        BuycookieButton.setOnClickListener() {
            if (money >= cookiePrice) {
                money - cookiePrice
                cookieStock + 1
                Money_TextView.text = "gold $money"
                CookieStockTextView.text = "stock $cookieStock"
            }
        }
        SelltoastButton.setOnClickListener() {
            if (toastStock > 0) {
                toastStock - 1
                money + toastPrice
                Money_TextView.text = "gold $money"
                ToastStockTextView.text = "stock $toastStock"
            }
        }
        BuytoastButton.setOnClickListener() {
            if (money >= toastPrice) {
                money - toastPrice
                toastStock + 1
                Money_TextView.text = "gold $money"
                ToastStockTextView.text = "stock $toastStock"
            }
        }
        Sellsword1Button.setOnClickListener() {
            if (sword1Stock > 0) {
                sword1Stock - 1
                money + sword1Price
                Money_TextView.text = "gold $money"
                Sword1StockTextView.text = "stock $sword1Stock"
            }
        }
        Buysword1Button.setOnClickListener() {
            if (money >= sword1Price) {
                money - sword1Price
                sword1Stock + 1
                Money_TextView.text = "gold $money"
                Sword1StockTextView.text = "stock $sword1Stock"
            }
        }
        Sellsword2Button.setOnClickListener() {
            if (sword2Stock > 0) {
                sword2Stock - 1
                money + sword2Price
                Money_TextView.text = "gold $money"
                Sword2StockTextView.text = "stock $sword2Stock"
            }
        }
        Buysword2Button.setOnClickListener() {
            if (money >= sword2Price) {
                money - sword2Price
                sword2Stock + 1
                Money_TextView.text = "gold $money"
                Sword2StockTextView.text = "stock $sword2Stock"
            }
        }
        SellspearButton.setOnClickListener() {
            if (spearStock > 0) {
                spearStock - 1
                money + spearPrice
                Money_TextView.text = "gold $money"
                SpearStockTextView.text = "stock $spearStock"
            }
        }
        BuyspearButton.setOnClickListener() {
            if (money >= spearPrice) {
                money - spearPrice
                spearStock + 1
                Money_TextView.text = "gold $money"
                BreadStockTextView.text = "stock $spearStock"
            }
        }
        SellhalberdButton.setOnClickListener() {
            if (halberdStock > 0) {
                halberdStock - 1
                money + spearPrice
                Money_TextView.text = "gold $money"
                HalberdStockTextView.text = "stock $halberdStock"
            }
        }
        BuyhalberdButton.setOnClickListener() {
            if (money >= halberdPrice) {
                money - halberdPrice
                halberdStock + 1
                Money_TextView.text = "gold $money"
                HalberdStockTextView.text = "stock $halberdStock"
            }
        }
        SellbowButton.setOnClickListener() {
            if (bowStock > 0) {
                bowStock - 1
                money + spearPrice
                Money_TextView.text = "gold $money"
                BowStockTextView.text = "stock $bowStock"
            }
        }
        BuybowButton.setOnClickListener() {
            if (money >= bowPrice) {
                money - bowPrice
                bowStock + 1
                Money_TextView.text = "gold $money"
                BowStockTextView.text = "stock $bowStock"
            }
        }
        SellspearButton.setOnClickListener() {
            if (leatherarmorStock > 0) {
                leatherarmorStock - 1
                money + leatherarmorPrice
                Money_TextView.text = "gold $money"
                LeatherArmorTextView.text = "stock $leatherarmorStock"
            }
        }
        BuyspearButton.setOnClickListener() {
            if (money >= leatherarmorPrice) {
                money - leatherarmorPrice
                spearStock + 1
                Money_TextView.text = "gold $money"
                LeatherArmorTextView.text = "stock $leatherarmorStock"
            }
        }
        SellchainmailarmorButton.setOnClickListener() {
            if (chainmailarmorStock > 0) {
                chainmailarmorStock - 1
                money + chainmailarmorPrice
                Money_TextView.text = "gold $money"
                ChainmailArmorStockTextView.text = "stock $chainmailarmorStock"
            }
        }
        BuychainmailarmorButton.setOnClickListener() {
            if (money >= chainmailarmorPrice) {
                money - chainmailarmorPrice
                chainmailarmorStock + 1
                Money_TextView.text = "gold $money"
                ChainmailArmorStockTextView.text = "stock $chainmailarmorStock"
            }
        }
        infoButton.setOnClickListener(){

            infodialog.setTitle("Information")
            infodialog.setMessage("This is a simple market simulation." +
                    "The price of items change when you press the next day button." +
                    "You buy items with the buy button and sell with the sell button." +
                    "ps all images in the app were made by me")
            infodialog.setMessage("Do you want to close this application ?")
                .setCancelable(false)
                .setPositiveButton("close", DialogInterface.OnClickListener {
                        dialog, id -> dialog.cancel()
                })





        }

    }

    @SuppressLint("SetTextI18n")
    fun NextDay() {
        NumberOfday += 1
        Day_TextView.text = "Days $NumberOfday"
        breadPriceChange()
        cookiePriceChange()
        toastPriceChange()
        sword1PriceChange()
        sword2PriceChange()
        spearPriceChange()
        halberdPriceChange()
        bowPriceChange()
        leatherarmorPriceChange()
        chainmailarmorPriceChange()
    }// everything the happens when the day changes
    @SuppressLint("SetTextI18n")
    fun breadPriceChange() {
        if (breadPrice > 75) {
            breadPrice - 7
        }
        if (breadPrice < 25) {
            breadPrice + 9
        } else {
            breadPriceChangeValue = (-10 until 10).random()
            breadPrice = breadPrice + (breadPriceChangeValue)
            BreadTextView.text = "$breadPrice" + "g"
        }
    }//code for how bread price changes
    @SuppressLint("SetTextI18n")
    fun cookiePriceChange() {
        if (cookiePrice > 150) {
            cookiePrice - 10
        }
        if (cookiePrice < 50) {
            cookiePrice + 13
        } else {
            cookiePriceChangeValue = (-15 until 15).random()
            if (cookiePriceChangeValue < 0) {
                cookiePriceChangeValue - 3
            }
            if (cookiePriceChangeValue > 0) {
                cookiePriceChangeValue + 3
            }
            cookiePrice = cookiePrice + (cookiePriceChangeValue)
            CookieTextView.text = "$cookiePrice" + "g"
        }
    }//code for how cookie price changes
    @SuppressLint("SetTextI18n")
    fun toastPriceChange() {
        if (toastPrice > 150000) {
            toastPrice - 35000
        }
        if (toastPrice < 50000) {
            toastPrice + 3500
        } else {
            toastPriceChangeValue = (-25 until 25).random()
            if (toastPriceChangeValue < 0) {
                toastPriceChangeValue * 1000
            }
            if (toastPriceChangeValue > 0) {
                toastPriceChangeValue * (10000)
            }
            toastPrice = toastPrice + (toastPriceChangeValue)
            ToastTextView.text = "$toastPrice" + "g"

        }
    }//code for how toast price changes
    @SuppressLint("SetTextI18n")
    fun sword1PriceChange() {
        if (sword1Price > 1500) {
            sword1Price - 123
        }
        if (sword1Price < 500) {
            sword1Price + 115
        } else {
            sword1PriceChangeValue = (-15 until 15).random()
            sword1PriceChangeValue * 10
            sword1Price = sword1Price + (sword1PriceChangeValue)
            Sword1TextView.text = "$sword1Price" + "g"
        }

    }//code for how iron sword price changes
    @SuppressLint("SetTextI18n")
    fun sword2PriceChange() {
        if (sword2Price > 2500) {
            sword2Price - 200
        }
        if (sword2Price < 1500) {
            sword2Price + 200
        } else {
            sword2PriceChangeValue = (-15 until 15).random()
            sword2PriceChangeValue * 10
            sword2Price = sword2Price + (sword2PriceChangeValue)
            Sword2TextView.text = "$sword2Price" + "g"
        }

    }//code for how steel sword price changes
    @SuppressLint("SetTextI18n")
    fun spearPriceChange() {
        if (spearPrice > 250) {
            spearPrice - 20
        }
        if (spearPrice < 750) {
            spearPrice + 20
        } else {
            spearPriceChangeValue = (-15 until 15).random()
            spearPriceChangeValue * 10
            spearPrice = spearPrice + (spearPriceChangeValue)
            SpearTextView.text = "$spearPrice" + "g"
        }
    }//code for how spear price changes
    @SuppressLint("SetTextI18n")
    fun halberdPriceChange() {
        if (halberdPrice > 3000) {
            halberdPrice - 348
        }
        if (halberdPrice < 2000) {
            halberdPrice + 357
        } else {
            halberdPriceChangeValue = (-25 until 25).random()
            halberdPriceChangeValue * 10
            halberdPrice = halberdPrice + (halberdPriceChangeValue)
            HalberdTextView.text = "$halberdPrice" + "g"
        }
    }//code for how halberd price changes
    @SuppressLint("SetTextI18n")
    fun bowPriceChange() {
        if (bowPrice > 1000) {
            bowPrice - 59
        }
        if (bowPrice < 500) {
            bowPrice + 56
        } else {
            bowPriceChangeValue = (-15 until 15).random()
            bowPriceChangeValue * 10
            bowPrice = bowPrice + (bowPriceChangeValue)
            BowTextView.text = "$bowPrice" + "g"
        }
    }//code for how bow price changes
    @SuppressLint("SetTextI18n")
    fun leatherarmorPriceChange() {
        if (leatherarmorPrice > 500) {
            leatherarmorPrice - 200
        }
        if (leatherarmorPrice < 1400) {
            leatherarmorPrice + 200
        } else {
            leatherarmorPriceChangeValue = (-15 until 15).random()
            leatherarmorPriceChangeValue * 10
            leatherarmorPrice = leatherarmorPrice + (leatherarmorPriceChangeValue)
            LeatherArmorTextView.text = "$leatherarmorPrice" + "g"
        }
    }//code for how leather armor price changes
    @SuppressLint("SetTextI18n")
    fun chainmailarmorPriceChange() {
        if (chainmailarmorPrice > 2300) {
            chainmailarmorPrice - 200
        }
        if (chainmailarmorPrice < 1300) {
            chainmailarmorPrice + 200
        } else {
            chainmailarmorPriceChangeValue = (-20 until 20).random()
            chainmailarmorPriceChangeValue * 10
            chainmailarmorPrice = chainmailarmorPrice + (chainmailarmorPriceChangeValue)
            ChainmailArmorTextView.text = "$chainmailarmorPrice" + "g"
        }
    }//code for how chainmail armor price changes
}